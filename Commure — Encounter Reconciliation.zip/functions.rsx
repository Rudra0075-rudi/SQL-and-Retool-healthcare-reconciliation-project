<GlobalFunctions>
  <SqlQueryUnified
    id="qKpis"
    query={include("./lib/qKpis.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="a0fa92da-e62c-4ef9-81e0-95c0ae0e1162"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="qReviewSummary"
    query={include("./lib/qReviewSummary.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="a0fa92da-e62c-4ef9-81e0-95c0ae0e1162"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="qProviderSummary"
    query={include("./lib/qProviderSummary.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="a0fa92da-e62c-4ef9-81e0-95c0ae0e1162"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="qMonthlySummary"
    isMultiplayerEdited={false}
    query={include("./lib/qMonthlySummary.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="a0fa92da-e62c-4ef9-81e0-95c0ae0e1162"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="qReviewQueue"
    query={include("./lib/qReviewQueue.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="a0fa92da-e62c-4ef9-81e0-95c0ae0e1162"
    warningCodes={[]}
  />
  <SqlQueryUnified
    id="query1"
    query={include("./lib/query1.sql", "string")}
    resourceDisplayName="retool_db"
    resourceName="a0fa92da-e62c-4ef9-81e0-95c0ae0e1162"
    warningCodes={[]}
  />
</GlobalFunctions>
