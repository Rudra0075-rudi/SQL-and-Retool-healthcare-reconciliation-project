SELECT
    provider_name,
    total_encounters,
    missing_encounters,
    missing_percentage / 100.0 AS missing_rate
FROM provider_summary
ORDER BY missing_percentage DESC, provider_name;