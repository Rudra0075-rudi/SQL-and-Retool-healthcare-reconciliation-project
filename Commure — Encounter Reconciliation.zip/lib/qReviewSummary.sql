SELECT
    review_group,
    encounter_count,
    percentage_of_missing
FROM review_summary
ORDER BY encounter_count DESC;