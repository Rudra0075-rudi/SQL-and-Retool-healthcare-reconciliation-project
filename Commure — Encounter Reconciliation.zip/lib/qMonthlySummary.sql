SELECT
    service_month,
    CASE service_month
        WHEN '2024-07' THEN 'July'
        WHEN '2024-08' THEN 'August'
        WHEN '2024-09' THEN 'September'
        ELSE service_month
    END AS month_label,
    total_encounters,
    missing_encounters,
    missing_percentage / 100.0 AS missing_rate
FROM monthly_summary
ORDER BY service_month;