SELECT
    id,
    patient_name,
    service_date,
    provider_name,
    encounter_group,
    review_group
FROM missing_review_queue
ORDER BY review_group, service_date, provider_name, patient_name;
