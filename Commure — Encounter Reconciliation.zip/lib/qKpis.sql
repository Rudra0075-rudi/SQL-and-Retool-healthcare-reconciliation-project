
SELECT *
FROM dashboard_kpis
LIMIT 1;