SELECT
    provider_name,
    review_group,
    COUNT(*) AS encounter_count
FROM missing_review_queue
WHERE LOWER(provider_name) LIKE '%young%'
GROUP BY provider_name, review_group;